<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap">
    <h1>Meetings</h1>
    <p>Manage meetings here (prototype)</p>
</div>
