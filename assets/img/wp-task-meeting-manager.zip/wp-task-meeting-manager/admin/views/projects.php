<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap">
    <h1>Projects</h1>
    <p>List and manage projects (prototype)</p>
</div>
