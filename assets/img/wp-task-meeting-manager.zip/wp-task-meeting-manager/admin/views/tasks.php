<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap">
    <h1>Tasks</h1>
    <p>Manage tasks here (prototype)</p>
</div>
