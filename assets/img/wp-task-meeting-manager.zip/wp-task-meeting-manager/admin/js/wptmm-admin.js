(function($){ $(document).ready(function(){
    $(document).on('click','#wptmm_add_stakeholder',function(e){
        e.preventDefault();
        var html = '<div class="form-row stakeholder-row"><div class="form-group col-md-6"><input class="form-control" name="stakeholder_type[]" placeholder="Stakeholder Type"/></div><div class="form-group col-md-6"><input class="form-control" name="stakeholder_name[]" placeholder="Name"/></div></div>';
        $('#wptmm_stakeholders_wrap').append(html);
    });

    $('#wptmm_project_form').on('submit', function(e){
        e.preventDefault();
        var data = $(this).serialize();
        data += '&nonce=' + wptmm_ajax.nonce;
        $.post(wptmm_ajax.ajax_url + '?action=wptmm_save_project', data, function(resp){
            if(resp.success){ alert('Project saved (ID: '+resp.data.id+')'); $('#wptmmProjectModal').modal('hide'); }
            else alert('Error: '+(resp.data||'Unknown'));
        }, 'json');
    });

    $('#wptmm_day_closing_btn').on('click', function(){
        var modal = '<div class="modal fade" id="wptmmDayModal"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5>Daily Closing</h5><button class="close" data-dismiss="modal">&times;</button></div><div class="modal-body"><form id="wptmm_day_form"><label>Daily Closing Date*:</label><input class="form-control" name="closing_date" value="'+new Date().toISOString().slice(0,10)+'"/><label>Key Highlights:</label><textarea class="form-control" name="highlights"></textarea><br/><button class="button button-primary" type="submit">Submit</button></form></div></div></div></div>';
        $('body').append(modal); $('#wptmmDayModal').modal('show');
        $(document).on('submit','#wptmm_day_form',function(e){
            e.preventDefault();
            var d = $(this).serialize();
            d += '&nonce=' + wptmm_ajax.nonce;
            $.post(wptmm_ajax.ajax_url + '?action=wptmm_save_daily', d, function(resp){ if(resp.success){ alert('Daily saved'); $('#wptmmDayModal').modal('hide'); } else alert('Error'); }, 'json');
        });
    });

}); })(jQuery);
