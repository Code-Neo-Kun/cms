<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
global $wpdb;
$prefix = $wpdb->prefix;
$tables = array('wptmm_clients','wptmm_projects','wptmm_stakeholders','wptmm_meetings','wptmm_tasks','wptmm_daily_closing');
foreach($tables as $t){
    $wpdb->query('DROP TABLE IF EXISTS '.$prefix.$t);
}
