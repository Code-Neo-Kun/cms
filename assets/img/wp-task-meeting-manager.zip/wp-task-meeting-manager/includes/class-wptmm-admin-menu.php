<?php
if (!defined('ABSPATH')) exit;

class WPTMM_Admin_Menu {

    public static function register_menus(){
        add_menu_page('WP Task & Meeting Manager','WP Task & Meeting Manager','read','wptmm_dashboard', array('WPTMM_Admin_Menu','render_dashboard'),'dashicons-clipboard',6);
        add_submenu_page('wptmm_dashboard','Dashboard','Dashboard','read','wptmm_dashboard', array('WPTMM_Admin_Menu','render_dashboard'));
        add_submenu_page('wptmm_dashboard','Meetings','Meetings','wptmm_view_meetings','wptmm_meetings', array('WPTMM_Admin_Menu','render_meetings'));
        add_submenu_page('wptmm_dashboard','Tasks','Tasks','wptmm_view_tasks','wptmm_tasks', array('WPTMM_Admin_Menu','render_tasks'));
        add_submenu_page('wptmm_dashboard','Projects','Projects','wptmm_view_projects','wptmm_projects', array('WPTMM_Admin_Menu','render_projects'));
    }

    public static function enqueue_assets($hook){
        if(strpos($hook,'wptmm')===false && $hook !== 'toplevel_page_wptmm_dashboard') return;
        wp_enqueue_style('wptmm_bootstrap','https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.2/css/bootstrap.min.css');
        wp_enqueue_script('wptmm_bootstrap_js','https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.2/js/bootstrap.bundle.min.js', array('jquery'),'4.6.2', true);
        wp_enqueue_style('wptmm_admin_css', plugins_url('../assets/css/wptmm-admin.css', __FILE__));
        wp_enqueue_script('wptmm_admin_js', plugins_url('../admin/js/wptmm-admin.js', __FILE__), array('jquery'), WPTMM_VERSION, true);
        wp_localize_script('wptmm_admin_js','wptmm_ajax', array('ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('wptmm-nonce')));
    }

    public static function render_dashboard(){
        include __DIR__ . '/../admin/views/dashboard.php';
    }
    public static function render_meetings(){
        include __DIR__ . '/../admin/views/meetings.php';
    }
    public static function render_tasks(){
        include __DIR__ . '/../admin/views/tasks.php';
    }
    public static function render_projects(){
        include __DIR__ . '/../admin/views/projects.php';
    }

    // placeholder for actions from forms (can be extended)
    public static function maybe_handle_actions(){
        // reserved
    }
}
