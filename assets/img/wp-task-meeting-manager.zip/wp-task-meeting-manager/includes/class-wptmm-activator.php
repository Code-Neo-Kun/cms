<?php
if (!defined('ABSPATH')) exit;

class WPTMM_Activator {

    public static function activate(){
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $t_clients      = $wpdb->prefix . 'wptmm_clients';
        $t_projects     = $wpdb->prefix . 'wptmm_projects';
        $t_meetings     = $wpdb->prefix . 'wptmm_meetings';
        $t_tasks        = $wpdb->prefix . 'wptmm_tasks';
        $t_stakeholders = $wpdb->prefix . 'wptmm_stakeholders';
        $t_daily        = $wpdb->prefix . 'wptmm_daily_closing';

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $sql = array();

        $sql[] = "CREATE TABLE $t_clients (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(191) NOT NULL,
            email varchar(191) DEFAULT NULL,
            website varchar(255) DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql[] = "CREATE TABLE $t_projects (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            generated_by varchar(191) DEFAULT NULL,
            project_name varchar(191) NOT NULL,
            email varchar(191) DEFAULT NULL,
            status varchar(100) DEFAULT NULL,
            website varchar(255) DEFAULT NULL,
            assign_to bigint(20) unsigned DEFAULT NULL,
            contact_person varchar(191) DEFAULT NULL,
            designation varchar(191) DEFAULT NULL,
            contact_number varchar(50) DEFAULT NULL,
            country varchar(100) DEFAULT 'India',
            zone varchar(100) DEFAULT NULL,
            state varchar(100) DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            address text DEFAULT NULL,
            zip_code varchar(20) DEFAULT NULL,
            expected_value decimal(18,2) DEFAULT NULL,
            expected_closure date DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";

        $sql[] = "CREATE TABLE $t_stakeholders (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned NOT NULL,
            stakeholder_type varchar(191) DEFAULT NULL,
            stakeholder_name varchar(191) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY (project_id)
        ) $charset_collate;";

        $sql[] = "CREATE TABLE $t_meetings (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned DEFAULT NULL,
            client_id bigint(20) unsigned DEFAULT NULL,
            title varchar(191) DEFAULT NULL,
            location varchar(255) DEFAULT NULL,
            date date DEFAULT NULL,
            time time DEFAULT NULL,
            description text DEFAULT NULL,
            status varchar(50) DEFAULT 'scheduled',
            priority varchar(50) DEFAULT 'normal',
            created_by bigint(20) unsigned DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY (date),
            KEY (status)
        ) $charset_collate;";

        $sql[] = "CREATE TABLE $t_tasks (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned DEFAULT NULL,
            client_id bigint(20) unsigned DEFAULT NULL,
            title varchar(191) DEFAULT NULL,
            priority varchar(50) DEFAULT 'normal',
            date date DEFAULT NULL,
            time time DEFAULT NULL,
            description text DEFAULT NULL,
            status varchar(50) DEFAULT 'pending',
            assigned_to bigint(20) unsigned DEFAULT NULL,
            created_by bigint(20) unsigned DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY (date),
            KEY (status)
        ) $charset_collate;";

        $sql[] = "CREATE TABLE $t_daily (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned DEFAULT NULL,
            closing_date date DEFAULT NULL,
            highlights text DEFAULT NULL,
            is_on_leave tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY (user_id)
        ) $charset_collate;";

        foreach($sql as $s){ dbDelta($s); }

        add_role('staff_user', 'Staff User', array(
            'read' => true,
            'level_0' => true,
        ));

        $caps = array(
            'wptmm_manage_meetings',
            'wptmm_view_meetings',
            'wptmm_manage_tasks',
            'wptmm_view_tasks',
            'wptmm_manage_projects',
            'wptmm_view_projects',
            'wptmm_view_reports',
            'wptmm_submit_daily'
        );

        $admin = get_role('administrator');
        $staff = get_role('staff_user');
        if($admin){ foreach($caps as $c) $admin->add_cap($c); }
        if($staff){
            $limited = array('wptmm_view_meetings','wptmm_view_tasks','wptmm_submit_daily');
            foreach($limited as $c) $staff->add_cap($c);
        }
    }

    public static function deactivate(){
        $caps = array('wptmm_manage_meetings','wptmm_view_meetings','wptmm_manage_tasks','wptmm_view_tasks','wptmm_manage_projects','wptmm_view_projects','wptmm_view_reports','wptmm_submit_daily');
        $admin = get_role('administrator');
        if($admin){ foreach($caps as $c) $admin->remove_cap($c); }
    }
}
