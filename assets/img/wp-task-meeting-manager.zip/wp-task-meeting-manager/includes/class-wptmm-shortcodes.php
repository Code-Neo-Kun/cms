<?php
if (!defined('ABSPATH')) exit;

class WPTMM_Shortcodes {

    public static function register_shortcodes(){
        add_shortcode('wptmm_my_tasks', array(__CLASS__,'my_tasks_shortcode'));
    }

    public static function my_tasks_shortcode($atts){
        if(!is_user_logged_in()) return '<p>Please login to see your tasks.</p>';
        global $wpdb;
        $user = wp_get_current_user();
        $t_tasks = $wpdb->prefix . 'wptmm_tasks';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t_tasks WHERE assigned_to=%d ORDER BY date ASC LIMIT 50", $user->ID));
        if(!$rows) return '<p>No tasks assigned.</p>';
        $out = '<table class=\"wptmm-frontend-tasks\"><thead><tr><th>Priority</th><th>Task</th><th>Date</th><th>Status</th></tr></thead><tbody>';
        foreach($rows as $r){ $out .= "<tr><td>{$r->priority}</td><td>{$r->title}</td><td>{$r->date}</td><td>{$r->status}</td></tr>"; }
        $out .= '</tbody></table>';
        return $out;
    }
}
