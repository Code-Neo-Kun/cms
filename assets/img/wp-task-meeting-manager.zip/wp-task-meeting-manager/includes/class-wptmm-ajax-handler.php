<?php
if (!defined('ABSPATH')) exit;

class WPTMM_Ajax_Handler {

    public static function init(){
        add_action('wp_ajax_wptmm_save_project', array(__CLASS__,'save_project'));
        add_action('wp_ajax_wptmm_save_daily', array(__CLASS__,'save_daily'));
    }

    public static function save_project(){
        check_ajax_referer('wptmm-nonce','nonce');
        if(!current_user_can('wptmm_manage_projects') && !current_user_can('wptmm_view_projects')) wp_send_json_error('No perms');
        global $wpdb;
        $t_projects = $wpdb->prefix . 'wptmm_projects';
        $data = array(
            'generated_by' => sanitize_text_field($_POST['generated_by'] ?? ''),
            'project_name' => sanitize_text_field($_POST['project_name'] ?? ''),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'status' => sanitize_text_field($_POST['status'] ?? ''),
            'website' => esc_url_raw($_POST['website'] ?? ''),
            'assign_to' => intval($_POST['assign_to'] ?? 0),
            'contact_person' => sanitize_text_field($_POST['contact_person'] ?? ''),
            'designation' => sanitize_text_field($_POST['designation'] ?? ''),
            'contact_number' => sanitize_text_field($_POST['contact_number'] ?? ''),
            'country' => sanitize_text_field($_POST['country'] ?? ''),
            'zone' => sanitize_text_field($_POST['zone'] ?? ''),
            'state' => sanitize_text_field($_POST['state'] ?? ''),
            'city' => sanitize_text_field($_POST['city'] ?? ''),
            'address' => sanitize_textarea_field($_POST['address'] ?? ''),
            'zip_code' => sanitize_text_field($_POST['zip_code'] ?? ''),
            'expected_value' => floatval($_POST['expected_value'] ?? 0),
            'expected_closure' => sanitize_text_field($_POST['expected_closure'] ?? ''),
        );
        $wpdb->insert($t_projects,$data);
        $project_id = $wpdb->insert_id;
        $stake_types = $_POST['stakeholder_type'] ?? array();
        $stake_names = $_POST['stakeholder_name'] ?? array();
        $t_stake = $wpdb->prefix . 'wptmm_stakeholders';
        for($i=0;$i<count($stake_types);$i++){
            $type = sanitize_text_field($stake_types[$i]);
            $name = sanitize_text_field($stake_names[$i] ?? '');
            if(empty($type) && empty($name)) continue;
            $wpdb->insert($t_stake, array('project_id'=>$project_id,'stakeholder_type'=>$type,'stakeholder_name'=>$name));
        }
        wp_send_json_success(array('id'=>$project_id));
    }

    public static function save_daily(){
        check_ajax_referer('wptmm-nonce','nonce');
        if(!current_user_can('wptmm_submit_daily')) wp_send_json_error('No perms');
        global $wpdb;
        $t_daily = $wpdb->prefix . 'wptmm_daily_closing';
        $wpdb->insert($t_daily, array('user_id'=>get_current_user_id(),'closing_date'=>sanitize_text_field($_POST['closing_date']),'highlights'=>sanitize_textarea_field($_POST['highlights']),'is_on_leave'=>intval($_POST['is_on_leave'] ?? 0)));
        wp_send_json_success();
    }
}

WPTMM_Ajax_Handler::init();
