<?php
// helper functions for WPTMM

if (!defined('ABSPATH')) exit;

function wptmm_format_date($date){
    if(empty($date)) return '';
    return date_i18n(get_option('date_format'), strtotime($date));
}
