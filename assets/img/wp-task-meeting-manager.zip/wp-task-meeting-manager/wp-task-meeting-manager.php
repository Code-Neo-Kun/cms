<?php
/**
 * Plugin Name: WP Task & Meeting Manager
 * Description: A lightweight Task & Meeting Manager for WordPress. (Prototype) Includes DB creation on activation, roles/capabilities, admin dashboard, project modal, tasks/meetings and simple reporting + frontend shortcode.
 * Version: 0.1
 * Author: ChatGPT (editable)
 */

if (!defined('ABSPATH')) exit;

define('WPTMM_VERSION','0.1');
define('WPTMM_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Includes
require_once __DIR__ . '/includes/class-wptmm-activator.php';
require_once __DIR__ . '/includes/class-wptmm-admin-menu.php';
require_once __DIR__ . '/includes/class-wptmm-ajax-handler.php';
require_once __DIR__ . '/includes/class-wptmm-shortcodes.php';

// Activation / Deactivation
register_activation_hook(__FILE__, array('WPTMM_Activator','activate'));
register_deactivation_hook(__FILE__, array('WPTMM_Activator','deactivate'));

// Init hooks
add_action('admin_enqueue_scripts', array('WPTMM_Admin_Menu','enqueue_assets'));
add_action('admin_menu', array('WPTMM_Admin_Menu','register_menus'));
add_action('init', array('WPTMM_Shortcodes','register_shortcodes'));

// Bootstrap admin page loader
add_action('admin_init', array('WPTMM_Admin_Menu','maybe_handle_actions'));
